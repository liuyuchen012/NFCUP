#__init__
#Developer name:liuyuchen
#Developer email:liuyuchen032901@outlook.com
#@2023-2024 nfcup
from nfcup import *